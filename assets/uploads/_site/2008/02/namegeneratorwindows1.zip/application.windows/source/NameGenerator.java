import processing.core.*; import java.applet.*; import java.awt.*; import java.awt.image.*; import java.awt.event.*; import java.io.*; import java.net.*; import java.text.*; import java.util.*; import java.util.zip.*; import javax.sound.midi.*; import javax.sound.midi.spi.*; import javax.sound.sampled.*; import javax.sound.sampled.spi.*; import java.util.regex.*; import javax.xml.parsers.*; import javax.xml.transform.*; import javax.xml.transform.dom.*; import javax.xml.transform.sax.*; import javax.xml.transform.stream.*; import org.xml.sax.*; import org.xml.sax.ext.*; import org.xml.sax.helpers.*; public class NameGenerator extends PApplet {/*

NameGenerator
por Herbert Spencer
Febrero de 2008 

*/



public void setup(){
  size(900, 600);
  tipo = loadFont("bodoni150.vlw");
  sans = loadFont("sans.vlw");
  smooth();
  noLoop();
  input = '1'; // default
  NombresAntiguos = loadStrings("nombres.txt");
  grabar = false;
  haGrabado = false;
  recCount = 0;
  // dejar los contadores en 0
  for(int i = 0; i < vocalCount.length; i++){
    vocalCount[i] = 0;
  }
  for(int i = 0; i < consonanteCount.length; i++){
    consonanteCount[i] = 0;
  }
  textAlign(CENTER);
}

public void draw(){
  background(0);

  if(!grabar){
    generaNombre();
    pintaNombre();
  }
  else{
    pintaNombre();
    fill(255);
    text(nombre + " se ha grabado al archivo de texto", width/2, 50);
    grabar = false;
  }

  barrasVocales();
  barrasConsonantes();
  instrucciones();
}


public void generaNombre(){
  switch(input){
    case '1':
    nombre = ""+C()+V()+C()+V();
    modo = "C V C V";
    break;
    case '2':
    nombre = ""+C()+V()+ V()+C()+V();
    modo = "C V V C V";
    break;
    case '3':
    nombre = ""+V()+C()+V();
    modo = "V C V";
    break;
    case '4':
    nombre = ""+C()+V()+V();
    modo = "C V V";
    break;
    case '5':
    nombre = ""+C()+V()+C()+V()+C();
    modo = "C V C V C";
    break;
    case '6':
    nombre = ""+C()+V()+C()+V()+C()+V();
    modo = "C V C V C V";
    break;
    case '7':
    nombre = ""+V()+C()+V()+C()+V();
    modo = "V C V C V";
    break;
    case '8':
    nombre = ""+C()+V()+C()+C()+V();
    modo = "C V C C V";
    break;
    case '9':
    nombre = ""+C()+V()+C()+V()+V()+C()+V();
    modo = "C V C V V C V";
    break;
    case '0':
    nombre = ""+C()+V()+C()+V()+C();
    modo = "C V C V C";
    break;
  }
}

public void pintaNombre(){
  textFont(tipo, 150);
  fill(0xffED0E9F);
  text(nombre, width/2, (height/2)+ textDescent());
  textFont(sans);
  fill(255);
  text(modo, width/2, 20);
}

public char V(){
  int r = PApplet.parseInt(random(vocal.length));
  char v = vocal[r];
  vocalCount[r] ++;
  return v;
}

public char C(){
  int r = PApplet.parseInt(random(consonante.length));
  char c = consonante[r];
  consonanteCount[r] ++;
  return c;
}

public void keyPressed(){
  input = key;
  if(key =='q'){
    if(haGrabado){
    NombresBuenos.flush();
    NombresBuenos.close();}
    exit();
  }
  if(key ==' '){
    recCount++;
    if (recCount == 1){
      logInit();
    }
    NombresBuenos.println(nombre);
    grabar = true;
    redraw();
  }
  redraw();
}

public void barra(int index, char letra, int count, int x, int y){
  textFont(sans);
  fill(255);
  text(letra, x, y + 20);
  fill(255, 100);
  int desp = (index % 2) * 15;
  text(count, x, y + 35 + desp);
  stroke(0xffED0E9F);
  line(x, y, x, y-count);
}

public void barrasVocales(){
  for (int i = 0; i < vocal.length; i++){
  barra(i, vocal[i], vocalCount[i], 100 + (i*15), height - 100);
  }
}

public void barrasConsonantes(){
  for (int i = 0; i < consonante.length; i++){
  barra(i, consonante[i], consonanteCount[i], 500 + (i*15), height - 100);
  }
}

public void instrucciones(){
  fill(255, 80);
  text("presione los n\u00fameros (1,2,3,4,5,6,7,8,9,0) para elegir el patr\u00f3n de consonantes (C) y vocales (V) de generaci\u00f3n de nombre", width/2, height - 20);
}

public void logInit(){
  NombresBuenos = createWriter("nombres.txt");
  for (int i = 0; i < NombresAntiguos.length; i++){
    NombresBuenos.println(NombresAntiguos[i]);
  }
  NombresBuenos.print("\n\n-----------------\n"+
            month() + "/" + day()+ "/" + year() + "   "+
            hour()+ ":" + minute()+"\n-----------------\n\n");
  haGrabado = true;
}

char[] vocal = {
  'a', 'e', 'i', 'o', 'u'};

char[] consonante = {
  'b', 'c', 'd', 'f',
  'g', 'h', 'j', 'k',
  'l', 'm', 'n', 'p',
  'q', 'r', 's', 't',
  'v', 'w', 'x', 'y',
  'z'};

int[] vocalCount = new int[vocal.length];
int[] consonanteCount = new int[consonante.length];

PFont tipo, sans;
String nombre;
String modo;
char input;
String[] NombresAntiguos;
PrintWriter NombresBuenos;
int recCount;
boolean grabar;
boolean haGrabado;

  static public void main(String args[]) {     PApplet.main(new String[] { "NameGenerator" });  }}