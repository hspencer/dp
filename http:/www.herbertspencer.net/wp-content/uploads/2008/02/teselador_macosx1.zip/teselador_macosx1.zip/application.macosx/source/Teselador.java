import processing.core.*; import processing.pdf.*; import java.applet.*; import java.awt.*; import java.awt.image.*; import java.awt.event.*; import java.io.*; import java.net.*; import java.text.*; import java.util.*; import java.util.zip.*; import javax.sound.midi.*; import javax.sound.midi.spi.*; import javax.sound.sampled.*; import javax.sound.sampled.spi.*; import java.util.regex.*; import javax.xml.parsers.*; import javax.xml.transform.*; import javax.xml.transform.dom.*; import javax.xml.transform.sax.*; import javax.xml.transform.stream.*; import org.xml.sax.*; import org.xml.sax.ext.*; import org.xml.sax.helpers.*; public class Teselador extends PApplet {//import processing.video.*; //quitar los comentarios para poder grabar

/*
 - Teselaci\u00f3n de Traves\u00eda
 - Pueblo Nuevo de Chalala
 - 
 - Taller de Primer A\u00f1o Dise\u00f1o
*/
 
 
//MovieMaker cam;

Tesela[] teselas;

public void setup(){
  size(792, 612); //hoja carta apaizada
  smooth();
  strokeCap(SQUARE);
  calcularNumeroDeTeselas();
  crearTeselas();
  ubicarTeselas();
  //cam = new MovieMaker(this, width, height, "t2.mov",  30, MovieMaker.ANIMATION, MovieMaker.HIGH);

}

public void draw(){
  if (fondo){
    background(0xffA8AF9F);
  }
  else {
    background(255);
  }
  if(pdf){
    nombre = "teselacion_"+day()+"_"+month()+"_"+year()+"_#"+counter+".pdf";
    p = beginRecord(PDF, "PDF/"+nombre);
    p.strokeCap(SQUARE); 
  }
  dibujarTeselas();
  if(pdf){
    endRecord();
    pdf = false;
    counter++;
    fill(255,0,0);
    noStroke();
    ellipse(width/2, height/2, height/3, height/3);
    noFill();
  }
  //cam.addFrame();
}

class Tesela{

  float a, hTercio, distanciaMouse;
  float xpos, ypos, x1, y1, z1, x2, y2, z2, x3, y3, z3;
  float rot, rotTarget;
  int giros, tipo;
  boolean parada, girando, sobre;

  Tesela(float _a, float _xpos, float _ypos, boolean _parada ){
    a = _a;
    xpos = _xpos;
    ypos = _ypos;
    parada = _parada;
    giros = PApplet.parseInt(random(4));
    rot = TWO_PI/3.0f * PApplet.parseFloat(giros);
    tipo = PApplet.parseInt(random(7)) + 1;
  }

  public void dibujar(){
    hTercio = sqrt(3)*a/6;
    float dif;
    if(girando){
      dif = rotTarget - rot;
      rot += dif * 0.2f;
      if (dif < 0.01f){
        rot = rotTarget;
        girando = false;
      }
    }
    
    pushMatrix();
    {
      translate(xpos, ypos);
      if(!parada){
        rotate(PI/3);
      }
      rotate(rot);
      
      if (sobre){
        fill(0xffFFF9F7);
        strokeWeight(0.25f);
        stroke(0xffE51515);
        beginShape();
        vertex(-a/2, hTercio);
        vertex(a/2, hTercio);
        vertex(0, -2*hTercio);
        endShape(CLOSE);
        noFill();
      }
      else{
        noFill();
      }
      if(lineas && !sobre){
        strokeWeight(0.25f);
        stroke(100);
        beginShape();
        vertex(-a/2, hTercio);
        vertex(a/2, hTercio);
        vertex(0, -2*hTercio);
        endShape(CLOSE);
      }
      if(fondo && !sobre){
        fill(255);
        noStroke();
        beginShape();
        vertex(-a/2, hTercio);
        vertex(a/2, hTercio);
        vertex(0, -2*hTercio);
        endShape(CLOSE);
      }

        if(sobre) {
        stroke(0xffE51515);
      }
      else {
        stroke(0);
      }
        switch(tipo){
        case 1:
          tipo1();
          break;
        case 2:
          tipo2();
          break;
        case 3:
          tipo3();
          break;
        case 4:
          tipo4();
          break;
        case 5:
          tipo5();
          break;
        case 6:
          tipo6();
          break;
        case 7:
          tipo7();
          break;
      }
    }
    popMatrix();
    calc();
  }

  public void tipo1(){ // cl\u00e1sica: arco circular + segmento recto corto
    strokeWeight(grosor);
    arc(0, -2*hTercio, a, a, PI/3, TWO_PI/3);
    line(0, hTercio, 0, hTercio*0.7f);
  }


  public void tipo2(){ // quebrada: uni\u00f3n perpendicular quebrada al centro + trazo quebrado a la izquierda
    strokeWeight(grosor);
    beginShape(); 
    vertex(-a/4, -hTercio/2);
    vertex(0,0);
    vertex(a/4, -hTercio/2);
    endShape();

    beginShape();
    vertex(0, hTercio);
    vertex(0, hTercio*0.8f);
    vertex(a*0.15f, hTercio*0.5f);
    endShape();
  }

  public void tipo3(){ 
    strokeWeight(grosor);
    bezier(-a/4, -hTercio/2, 0, 0, 0, 0, a/4, -hTercio/2);
    arc(a/4, hTercio, a/2, a/2, PI*3, -PI/2);
  }

  public void tipo4(){ // cl\u00e1sica fina: arco circular + arco de medio circulo
    strokeWeight(grosor);
    arc(0, -2*hTercio, a, a, PI/3, TWO_PI/3);
    noStroke();
    if(sobre){fill(0xffE51515);}else{fill(0);}
    arc(0, hTercio, grosor, grosor, PI, -TWO_PI);
    noFill();
  }
  
  public void tipo5(){
    strokeWeight(grosor);
    strokeCap(ROUND);
    if(pdf){
       p.strokeCap(ROUND);
    }
    line(-a/4, -hTercio/2,a/4, -hTercio/2);
    line(0, hTercio, hTercio*0.15f, hTercio*0.7f);
    strokeCap(SQUARE);
    if(pdf){
      p.strokeCap(SQUARE);
    }
  }
  
  public void tipo6(){
  strokeWeight(grosor);
  noFill();
      strokeCap(ROUND);
    if(pdf){
       p.strokeCap(ROUND);
    }
  arc(0, 4*hTercio, 2*a, 2*a, -PI*2/3, -PI/3);
      strokeCap(SQUARE);
    if(pdf){
      p.strokeCap(SQUARE);
    }
  arc(0, -2*hTercio, a, a, PI/3, TWO_PI/3);
  }

  public void tipo7(){ //arco entre dos v\u00e9rtices
    strokeWeight(grosor);
    noFill();
          strokeCap(ROUND);
    if(pdf){
       p.strokeCap(ROUND);
    }
    arc(0, 4*hTercio, 2*a, 2*a, -PI*2/3, -PI/3);
          strokeCap(SQUARE);
    if(pdf){
      p.strokeCap(SQUARE);
    }
  }

  public void calc(){
    distanciaMouse = dist(xpos,ypos, mouseX, mouseY);
    if(distanciaMouse < sqrt(3)*a/6){
      sobre = true;
    }
    else {
      sobre = false;
    }
  }
}

/*fullscreen
static public void main(String args[]) {
  PApplet.main(new String[] { 
    "--display=1", "--present", "Teselador"                            }
  );
}
*/

public void calcularNumeroDeTeselas(){
  numX = PApplet.parseInt((width)/(A/2))+1;
  numY = PApplet.parseInt((height)/(sqrt(3)*A/2))+1;
  teselas = new Tesela[numX*numY];
}

public void crearTeselas(){
  for (int i = 0; i < teselas.length; i++){
    teselas[i] = new Tesela (A*0.95f, -1000, -1000, false);
  }
}


public void ubicarTeselas(){

  int c = 0;

  for (int y = 0; y < numY; y++){
    for(int x = 0; x < numX; x++){

      modY = y % 2;
      modX = x % 2;

      teselas[c].xpos = (A/2 * x);

      if (modY == 1){
        teselas[c].ypos = (sqrt(3)*A/2 * y) + (modX * sqrt(3) * A/6);
        if (modX == 1){
          teselas[c].parada = true;
        }
      }
      else{
        teselas[c].ypos = (sqrt(3)*A/2 * y) + (modX+1 * sqrt(3) * A/6);
        if (modX == 0){
          teselas[c].parada = true;
        }
        else{
          teselas[c].ypos -= sqrt(3)*A/6;
        }
      }
      c ++;
      if(c > teselas.length){
        break;
      }
    }
  }
}

public void dibujarTeselas(){
  for (int i = 0; i < teselas.length; i++){
    teselas[i].dibujar();
  }
}

public void agrandarTeselas(){
  for (int i = 0; i < teselas.length; i++){
    teselas[i].a ++;
  }
}

public void achicarTeselas(){
  for (int i = 0; i < teselas.length; i++){
    teselas[i].a --;
  }
}

public void agrandarEspacio(){
  A ++;
  ubicarTeselas();
}

public void achicarEspacio(){
  if(teselas[0].a <= A){
    A --;
  }
  ubicarTeselas();
}

public void todasMismoTipo(int tipo){
  for (int i = 0; i < teselas.length; i++){
    teselas[i].tipo = tipo;
  }
}

public void todasTipoCualquiera(){
  for (int i = 0; i < teselas.length; i++){
    teselas[i].tipo = PApplet.parseInt(random(7))+1;
  }
}

public void todasGiran(){
  for (int i = 0; i < teselas.length; i++){
    if(!teselas[i].girando){
      teselas[i].rotTarget = teselas[i].rot + TWO_PI/3 * PApplet.parseFloat(PApplet.parseInt(random(2))+1);
      teselas[i].girando = true;
    }
  }
}

public void mousePressed(){
  if (mouseButton == LEFT) {
    for (int i = 0; i < teselas.length; i++){
      if (teselas[i].sobre && !teselas[i].girando){
        teselas[i].rotTarget = teselas[i].rot + TWO_PI/3; //defino el destino de giro
        teselas[i].girando = true;
      }
    }
  }

  if(mouseButton == RIGHT){
    for (int i = 0; i < teselas.length; i++){
      if (teselas[i].sobre && !teselas[i].girando){
        teselas[i].tipo ++;
        if(teselas[i].tipo > 7){ 
          teselas[i].tipo = 1;
        }
      }
    }
  }
}

/*
Teselaciones Equil\u00e1teras de Traves\u00eda
Purmamarca, Pueblo Nuevo de Chalala
Noviembre 2007
por Herbert Spencer

e.[ad] Escuela de Arquitectura y Dise\u00f1o
Taller de Primer A\u00f1o Dise\u00f1o


INSTRUCCIONES

+ MOUSE CLICK: rotar tesela

+ MOUSE RIGHT CLICK: cambiar tipo de tesela

+ A-Z: controlar el tama\u00f1o de las teselas

+ S-X: controlar el grosor del mortero

+ D-C: controlar el grosor del trazo del dibujo

+ ESPACIO: mostrar u ocultar las l\u00edneas de borde del tesel

+ F: mostrar u ocultar el fondo del mortero

+ 1-2-3-4-5-6-7: dejar teselas iguales seg\u00fan tipo

+ 0: randomizar tipos

+ G: randomizar giros

+ R: recalcular ubicaci\u00f3n y n\u00famero de teselas

+ P: exportar archivo PDF*
     
+ Q: salir

* Se exportan archivos consecutivos en la carpeta PDF del programa


*/

public void keyPressed(){

  if (((key == 'a') || (key == 'A'))&&(teselas[0].a <= A)){
    agrandarTeselas();
  }
  if ((key == 'z') || (key == 'Z')){
    achicarTeselas();
  }
  if ((key == 's') || (key == 'S')){
    agrandarEspacio();
  }
  if ((key == 'x') || (key == 'X')){
    achicarEspacio();
  }
  if ((key == 'd') || (key == 'D')){
    grosor += 0.5f;
  }
  if ((key == 'c') || (key == 'C')){
    if(grosor > 1){
      grosor -= 0.5f;
    }
  }
  if ((key == 'g') || (key == 'G')){
    todasGiran();
  }
  if ((key == 'f') || (key == 'F')){
    fondo = !fondo;
  }
  if (key == ' '){
    lineas = !lineas;
  }
  if ((key == 'p') || (key == 'P')){
    pdf = true;
  }
  if (key == '1'){
    todasMismoTipo(1);
  }
  if (key == '2'){
    todasMismoTipo(2);
  }
  if (key == '3'){
    todasMismoTipo(3);
  }
  if (key == '4'){
    todasMismoTipo(4);
  }
  if (key == '5'){
    todasMismoTipo(5);
  }
  if (key == '6'){
    todasMismoTipo(6);
  }
  if (key == '7'){
    todasMismoTipo(7);
  }
  if (key == '0'){
    todasTipoCualquiera();
  }
  if ((key == 'r') || (key == 'R')){
    calcularNumeroDeTeselas();
    crearTeselas();
    ubicarTeselas();
  }
  if ((key == 'q') || (key == 'Q')){
    //cam.finish();
    exit();
  }
}


float modX, modY; // m\u00f3dulos en X e Y para la ubicaci\u00f3n de teselas
int numX, numY;   // cantidades en X e Y de teselas en la pantalla
float A = 160.0f;   // largo del lado de la tesela sin considerar el mortero, 
// ditancia entre centros

boolean lineas = false;  //switch para dibujar las l\u00edneas
boolean fondo = false;  //switch para los dibujos internos de las teselas
boolean pdf = false;

float grosor = 1.0f;
int counter = 1; //contador de pdfs

String nombre; // nombre del archivo PDF exportado

PGraphics p;

  static public void main(String args[]) {     PApplet.main(new String[] { "Teselador" });  }}